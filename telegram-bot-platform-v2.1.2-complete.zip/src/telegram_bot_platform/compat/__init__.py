"""Platform module."""
