"""Compatibility-preserving platform module."""
